package com.valorin.commands.way;

public interface InServerCommand {

}
