package com.valorin.event.sign;

import org.bukkit.Bukkit;
import org.bukkit.block.Sign;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import static com.valorin.configuration.languagefile.MessageSender.gm;

public class EventClickSign implements Listener {
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        if (e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
            if ((e.getClickedBlock().getState() instanceof Sign)) {
                Sign sign = (Sign) e.getClickedBlock().getState();
                String content = sign.getLine(0);
                if (content.equals("§9" + gm("[单挑匹配]", null))) {
                    Bukkit.dispatchCommand(e.getPlayer(), "dantiao st");
                }
            }
        }
    }
}
