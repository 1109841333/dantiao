package com.valorin.commands.way;

public interface AdminCommand {

}
