package com.valorin.event.gui;

import com.valorin.inventory.INVRecords;
import com.valorin.specialtext.Show;
import com.valorin.util.ViaVersion;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.valorin.configuration.languagefile.MessageSender.gm;
import static com.valorin.configuration.languagefile.MessageSender.sm;
import static com.valorin.inventory.INVRecords.pages;

public class EventRecordsGUI implements Listener {
    private final Map<String, Long> show = new HashMap<>();

    @EventHandler
    public void page(InventoryClickEvent e) {
        Player p = (Player) e.getWhoClicked();
        String pn = p.getName();
        Inventory inv = e.getInventory();
        if (inv == null) {
            return;
        }
        if (e.getView().getTitle().equals(gm("&0&l我的比赛记录 &9&l[right]", p))) {
            e.setCancelled(true);
            if (e.getRawSlot() == 49) {// 翻页
                int page = INVRecords.pages.get(pn);
                int maxPage = INVRecords.maxPages.get(pn);
                if (e.getClick().equals(ClickType.LEFT)) {
                    if (page != maxPage) {
                        INVRecords.loadItem(inv, pn, page + 1);
                        pages.put(pn, page + 1);
                        INVRecords.loadPageItem(inv, pn, page + 1);
                    }
                }
                if (e.getClick().equals(ClickType.RIGHT)) {
                    if (page != 1) {
                        INVRecords.loadItem(inv, pn, page - 1);
                        pages.put(pn, page - 1);
                        INVRecords.loadPageItem(inv, pn, page - 1);
                    }
                }
                return;
            }
            if (e.getRawSlot() > 8 && e.getRawSlot() < 45) {
                if (inv.getItem(e.getRawSlot()) != null) {
                    if (e.getClick().equals(ClickType.LEFT)) {
                        if (show.containsKey(pn)) {
                            if (System.currentTimeMillis() - show.get(pn) < 15000) {
                                sm("&a战绩展示太频繁啦~请等会再展示", p);
                                return;
                            }
                        }
                        show.put(pn, System.currentTimeMillis());
                        Show.showRecord(p, inv.getItem(e.getRawSlot()), null);
                    }
                    if (e.getClick().equals(ClickType.RIGHT)) {
                        ItemStack item = ViaVersion.getItemInMainHand(p);
                        if (item != null) {
                            if (item.getType().equals(Material.PAPER)) {
                                if (item.getAmount() == 1) {
                                    if (!item.hasItemMeta()) {
                                        ItemStack recordItem = inv.getItem(e
                                                .getRawSlot());
                                        ItemStack printedPaper = new ItemStack(
                                                Material.PAPER);
                                        ItemMeta printedPaperMeta = printedPaper
                                                .getItemMeta();
                                        printedPaperMeta.setDisplayName(gm(
                                                "&2{player}：", p, "player",
                                                new String[]{pn})
                                                + recordItem.getItemMeta()
                                                .getDisplayName());
                                        List<String> lore = recordItem
                                                .getItemMeta().getLore();
                                        lore.remove(lore.size() - 1);
                                        lore.remove(lore.size() - 1);
                                        lore.remove(lore.size() - 1);
                                        printedPaperMeta.setLore(lore);
                                        printedPaper
                                                .setItemMeta(printedPaperMeta);
                                        ViaVersion.setItemInMainHand(p, printedPaper);
                                        sm("&a战绩打印成功", p);
                                        return;
                                    }
                                }
                            }
                        }
                        sm("&a请将单张纸拿在手上才能打印战绩！", p);
                    }
                }
            }
        }
    }
}
